package com.firebaseloginapp1;

/**
 * Created by n01139945 on 10/23/2017.
 */

public class Name {
    String nameid;
    String nameName1;

    public Name(){

    }

    public Name(String nameid, String nameName1) {
        this.nameid = nameid;
        this.nameName1 = nameName1;
    }

    public String getNameid() {
        return nameid;
    }

    public String getNameName1() {
        return nameName1;
    }
}
